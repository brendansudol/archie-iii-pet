# Archie III — Extra animations

Four transparent, looping six-frame animations: skateboard, sunglasses, hearts, and an American football toss.

Use the individual GIFs anywhere you can use an animated image. Each is 192 × 208 pixels. The lossless WebP atlas is 1152 × 832 pixels: six columns, four rows. Row order and frame timing are recorded in archie-iii-extras.json.

These are supplemental web animations. The main Codex pet download keeps the standard v2 animation layout.

Website: https://brendansudol.github.io/archie-iii-pet/
