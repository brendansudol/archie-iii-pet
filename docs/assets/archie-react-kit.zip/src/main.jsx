import React, { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.jsx';
import './demo.css';

createRoot(document.getElementById('root')).render(<StrictMode><App /></StrictMode>);
