# Archie III

A cheerful pixel-art robotic dog with red armor, oversized ears, a cream muzzle, and a big smile. Your loyal creative companion, with a pencil for work and review.

## Install in Codex

Unzip the package and put the archie-iii folder in ~/.codex/pets/ (or $CODEX_HOME/pets/ when using a custom Codex home). The folder must contain pet.json and spritesheet.webp. Choose Archie III in the pet picker; reopen Codex if needed.

## Included

Codex pet format v2: 1536 × 2288 pixels, 8 columns × 11 rows, 192 × 208 pixel cells. Nine animations: idle, run right, run left, wave, jump, failed, waiting, work, and review. Sixteen clockwise look directions at 22.5° intervals, with 0° pointing up.

Website: https://brendansudol.github.io/archie-iii-pet/
Source: https://github.com/brendansudol/archie-iii-pet
